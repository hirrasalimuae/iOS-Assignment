//
//  SceneDelegate.h
//  iOS Assignment
//
//  Created by Hira Saleem on 28/07/2024.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end


//
//  Constants.h
//  iOS Assignment
//
//  Created by Hira Saleem on 28/07/2024.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString * const kEmployeesURL;
extern NSString * const kMalformedEmployeesURL;
extern NSString * const kEmptyEmployeesURL;

NS_ASSUME_NONNULL_END

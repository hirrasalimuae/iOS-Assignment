//
//  NetworkManagerFramework.h
//  NetworkManagerFramework
//
//  Created by Hira Saleem on 28/07/2024.
//

#import <Foundation/Foundation.h>

//! Project version number for NetworkManagerFramework.
FOUNDATION_EXPORT double NetworkManagerFrameworkVersionNumber;

//! Project version string for NetworkManagerFramework.
FOUNDATION_EXPORT const unsigned char NetworkManagerFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NetworkManagerFramework/PublicHeader.h>

#import <NetworkManagerFramework/NetworkManager.h>
